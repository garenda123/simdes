# 6. Report Creation

### 6.1. [FastReport Designer Community Edition](FastReportDesignerCommunityEdition.md)
### 6.2. [FastReport Online Designer](FastReportOnlineDesigner.md)
### 6.3. [Report Template File Structure](ReportTemplateFileStructure.md)
### 6.4. [Creating a Report by Using Code](CreatingReportUsingCode.md)

---

[Script](Script.md) | [Top Page](README.md) | [FastReport Designer Community Edition](FastReportDesignerCommunityEdition.md)
